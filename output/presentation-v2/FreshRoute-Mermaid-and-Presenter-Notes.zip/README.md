# FreshRoute presentation sources

The PowerPoint contains exactly 8 slides in the original Midnight Circuit design.
All diagram nodes, labels and edges are native editable PowerPoint objects.
The diagrams follow the accompanying Mermaid definitions and local Mermaid layouts.

## Included files

- mermaid/: 9 editable Mermaid definitions for the 8 slides (slide 5 uses two diagrams).
- svg/: vector renderings of those definitions.
- PRESENTER-NOTES.md: the same explanations and demonstration script embedded in PowerPoint notes.

## Using the files

Open .mmd files in a trusted local Mermaid editor. The source includes its palette and layout configuration.
Edit native shapes and labels directly in PowerPoint for small presentation changes.
Changes to a .mmd file do not automatically update the PowerPoint.
PowerPoint Presenter View shows the detailed notes while the audience sees the diagram.

## Team and factual boundaries

M R Krishni - 24BCE
Pratyush Purwar - 24BCE5254
Tanmay Suresh Kotadia - 24BCE5281

The first roll number intentionally matches the supplied prefix. Update it when the full number is available.
Use the retained-app, verified-and-deleted-lab and study-topic distinctions shown on slide 8.
The worked shipment is fictional. Its quality and quantity-at-risk values are model outputs, not measured savings or food-safety certification.
The neutral AI name describes the feature. Describe the actual configured provider accurately if asked.
